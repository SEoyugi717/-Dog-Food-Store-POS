<?php
include "sidebar.php";

if(isset($_POST['checkout'])){
    foreach($_POST['product_id'] as $index => $pid){
        $qty = $_POST['quantity'][$index];

        $product = $conn->query("SELECT * FROM products WHERE id=$pid")->fetch(PDO::FETCH_ASSOC);

        $total = $product['price'] * $qty;

        $conn->prepare("INSERT INTO sales (product_id, product_name, quantity, price, total, sale_date)
        VALUES (?,?,?,?,?,NOW())")
        ->execute([$pid, $product['name'], $qty, $product['price'], $total]);

        $conn->prepare("UPDATE products SET quantity = quantity - ? WHERE id=?")
        ->execute([$qty, $pid]);
    }

    $success = "Sale completed!";
}

$products = $conn->query("SELECT * FROM products")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">

<h3 class="mb-4">🛒 Sales Terminal</h3>

<?php if(isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>

<div class="row">

<!-- PRODUCTS GRID -->
<div class="col-lg-8">
    <div class="product-grid">

        <?php foreach($products as $p): ?>
            <div class="product-card"
                onclick="addToCart(<?= $p['id'] ?>,'<?= $p['name'] ?>',<?= $p['price'] ?>)">
                <h6><?= $p['name'] ?></h6>
                <p>Ksh <?= $p['price'] ?></p>
                <small>Stock: <?= $p['quantity'] ?></small>
            </div>
        <?php endforeach; ?>

    </div>
</div>

<!-- CART -->
<div class="col-lg-4">
    <div class="cart-box">
        <h5>🧾 Cart</h5>

        <form method="post" id="cartForm">
            <div id="cartItems"></div>

            <h4 class="mt-3">Total: Ksh <span id="total">0</span></h4>

            <button type="submit" name="checkout" class="btn btn-success w-100 mt-3">
                Checkout
            </button>
        </form>
    </div>
</div>

</div>
</div>

<!-- JS -->
<script>
let cart = [];

function addToCart(id, name, price){
    let item = cart.find(p => p.id === id);

    if(item){
        item.qty++;
    } else {
        cart.push({id, name, price, qty:1});
    }

    renderCart();
}

function renderCart(){
    let cartHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        total += item.price * item.qty;

        cartHTML += `
        <div class="cart-item">
            <strong>${item.name}</strong>
            <div>
                <button onclick="changeQty(${index}, -1)">-</button>
                ${item.qty}
                <button onclick="changeQty(${index}, 1)">+</button>
            </div>
            <span>Ksh ${item.price * item.qty}</span>

            <input type="hidden" name="product_id[]" value="${item.id}">
            <input type="hidden" name="quantity[]" value="${item.qty}">
        </div>
        `;
    });

    document.getElementById('cartItems').innerHTML = cartHTML;
    document.getElementById('total').innerText = total;
}

function changeQty(index, change){
    cart[index].qty += change;

    if(cart[index].qty <= 0){
        cart.splice(index,1);
    }

    renderCart();
}
</script>

<!-- STYLES -->
<style>

/* Product Grid */
.product-grid {
    display:grid;
    grid-template-columns: repeat(auto-fill,minmax(150px,1fr));
    gap:15px;
}

.product-card {
    background:white;
    padding:15px;
    border-radius:10px;
    cursor:pointer;
    text-align:center;
    box-shadow:0 5px 10px rgba(0,0,0,0.08);
    transition:0.3s;
}

.product-card:hover {
    transform:scale(1.05);
    background:#2f3640;
    color:white;
}

/* Cart */
.cart-box {
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

.cart-item {
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:10px;
    border-bottom:1px solid #eee;
    padding-bottom:8px;
}

.cart-item button {
    border:none;
    background:#40739e;
    color:white;
    padding:3px 8px;
    border-radius:5px;
    margin:0 5px;
}

</style>