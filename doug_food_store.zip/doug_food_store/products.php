<?php
include "sidebar.php";

// ADD PRODUCT
if(isset($_POST['add_product'])){
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $conn->prepare("INSERT INTO products (name, price, quantity) VALUES (?,?,?)")
        ->execute([$name, $price, $quantity]);
}

// DELETE PRODUCT
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM products WHERE id=$id");
}

// FETCH PRODUCTS
$products = $conn->query("SELECT * FROM products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">

<h3 class="mb-4">📦 Product Management</h3>

<!-- ADD PRODUCT -->
<div class="card p-4 mb-4">
    <h5>Add New Product</h5>
    <form method="post" class="row g-3 mt-2">
        <div class="col-md-4">
            <input type="text" name="name" class="form-control" placeholder="Product Name" required>
        </div>
        <div class="col-md-2">
            <input type="number" name="price" class="form-control" placeholder="Price" required>
        </div>
        <div class="col-md-2">
            <input type="number" name="quantity" class="form-control" placeholder="Quantity" required>
        </div>
        <div class="col-md-2">
            <button type="submit" name="add_product" class="btn btn-success w-100">Add</button>
        </div>
    </form>
</div>

<!-- SEARCH -->
<input type="text" id="search" class="form-control mb-4" placeholder="🔍 Search products...">

<!-- PRODUCT GRID -->
<div class="product-grid" id="productGrid">

<?php foreach($products as $p): ?>
    <div class="product-card" data-name="<?= strtolower($p['name']) ?>">

        <h5><?= $p['name'] ?></h5>
        <p>Ksh <?= $p['price'] ?></p>

        <span class="stock <?= $p['quantity'] <= 5 ? 'low' : '' ?>">
            <?= $p['quantity'] <= 5 ? '⚠ Low Stock' : 'In Stock' ?> (<?= $p['quantity'] ?>)
        </span>

        <div class="actions mt-3">
            <a href="?delete=<?= $p['id'] ?>" class="btn btn-danger btn-sm">Delete</a>
        </div>

    </div>
<?php endforeach; ?>

</div>

</div>

<!-- JS (SEARCH FILTER) -->
<script>
document.getElementById('search').addEventListener('keyup', function(){
    let value = this.value.toLowerCase();
    let cards = document.querySelectorAll('.product-card');

    cards.forEach(card => {
        let name = card.getAttribute('data-name');
        card.style.display = name.includes(value) ? 'block' : 'none';
    });
});
</script>

<!-- STYLING -->
<style>

/* GRID */
.product-grid {
    display:grid;
    grid-template-columns: repeat(auto-fill,minmax(220px,1fr));
    gap:20px;
}

/* CARD */
.product-card {
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
    transition:0.3s;
    position:relative;
}

.product-card:hover {
    transform:translateY(-5px) scale(1.02);
    box-shadow:0 10px 25px rgba(0,0,0,0.15);
}

/* STOCK BADGE */
.stock {
    display:inline-block;
    padding:5px 10px;
    border-radius:20px;
    background:#44bd32;
    color:white;
    font-size:12px;
}

.stock.low {
    background:#e84118;
}

/* ACTIONS */
.actions {
    display:flex;
    justify-content:space-between;
}

/* SEARCH */
#search {
    border-radius:10px;
    padding:10px;
}

/* FORM */
.card input {
    border-radius:8px;
}

</style>