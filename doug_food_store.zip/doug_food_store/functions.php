<?php
require_once "config.php";

// Check if user is logged in
function check_login() {
    session_start();
    if(!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }
}

// Get all products
function get_products() {
    global $conn;
    $stmt = $conn->query("SELECT * FROM products");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Add a sale and update stock
function add_sale($product_id, $quantity) {
    global $conn;
    // Get product info
    $stmt = $conn->prepare("SELECT price, quantity FROM products WHERE id=?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if($product && $product['quantity'] >= $quantity) {
        $total = $product['price'] * $quantity;

        // Insert sale
        $stmt = $conn->prepare("INSERT INTO sales (product_id, quantity, total_price) VALUES (?,?,?)");
        $stmt->execute([$product_id, $quantity, $total]);

        // Update stock
        $stmt = $conn->prepare("UPDATE products SET quantity = quantity - ? WHERE id = ?");
        $stmt->execute([$quantity, $product_id]);

        return true;
    } else {
        return false;
    }
}

// Low stock alert
function low_stock_alerts() {
    global $conn;
    $stmt = $conn->query("SELECT * FROM products WHERE quantity <= low_stock_threshold");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>