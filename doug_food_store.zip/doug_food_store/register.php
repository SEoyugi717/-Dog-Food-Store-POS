<?php
session_start();
require_once "config.php";

// Redirect if already logged in
if(isset($_SESSION['username'])){
    header("Location: index.php");
    exit();
}

$reg_error = '';
if(isset($_POST['register'])){
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role = $_POST['role'] ?? 'attendant';

    $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
    $stmt->execute([$username]);

    if($stmt->rowCount()>0){
        $reg_error="Username already exists!";
    } else {
        $hashed=password_hash($password,PASSWORD_DEFAULT);
        $stmt=$conn->prepare("INSERT INTO users (username,password,role) VALUES (?,?,?)");
        if($stmt->execute([$username,$hashed,$role])){
            $_SESSION['username']=$username;
            $_SESSION['role']=$role;
            header("Location:index.php");
            exit();
        } else {
            $reg_error="Registration failed.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register - Doug's Store</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container d-flex justify-content-center align-items-center vh-100">
<div class="card shadow p-4" style="width:400px;">
<h3 class="text-center mb-3">Register Account</h3>
<form method="post">
<input type="text" name="username" class="form-control mb-3" placeholder="Username" required>
<input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
<select name="role" class="form-select mb-3">
<option value="attendant">Attendant</option>
<option value="admin">Admin</option>
</select>
<?php if($reg_error) echo "<div class='alert alert-danger'>$reg_error</div>"; ?>
<button type="submit" name="register" class="btn btn-success w-100">Register</button>
</form>
<p class="mt-3 text-center">Already have an account? <a href="login.php">Login</a></p>
</div>
</div>
</body>
</html>