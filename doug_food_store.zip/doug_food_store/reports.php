<?php
include "sidebar.php";

// DATE FILTER
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';

$where = "";
if($start && $end){
    $where = "WHERE DATE(sale_date) BETWEEN '$start' AND '$end'";
}

// TOTAL SALES
$totalSales = $conn->query("SELECT SUM(total) as total FROM sales $where")
    ->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

// TODAY SALES
$todaySales = $conn->query("SELECT SUM(total) as total FROM sales WHERE DATE(sale_date)=CURDATE()")
    ->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

// TOTAL ORDERS
$totalOrders = $conn->query("SELECT COUNT(*) as count FROM sales $where")
    ->fetch(PDO::FETCH_ASSOC)['count'];

// TOP PRODUCTS
$topProducts = $conn->query("
    SELECT product_name, SUM(quantity) as qty 
    FROM sales 
    $where
    GROUP BY product_name 
    ORDER BY qty DESC 
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// DAILY SALES (FOR CHART)
$chartData = $conn->query("
    SELECT DATE(sale_date) as day, SUM(total) as total 
    FROM sales 
    GROUP BY day 
    ORDER BY day ASC
")->fetchAll(PDO::FETCH_ASSOC);

// SALES TABLE
$sales = $conn->query("SELECT * FROM sales $where ORDER BY id DESC LIMIT 20")
    ->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">

<h3 class="mb-4">📊 Reports Dashboard</h3>

<!-- FILTER -->
<form method="get" class="row g-3 mb-4">
    <div class="col-md-3">
        <input type="date" name="start" class="form-control" value="<?= $start ?>">
    </div>
    <div class="col-md-3">
        <input type="date" name="end" class="form-control" value="<?= $end ?>">
    </div>
    <div class="col-md-2">
        <button class="btn btn-primary w-100">Filter</button>
    </div>
</form>

<!-- CARDS -->
<div class="row">

<div class="col-md-4">
    <div class="report-card">
        <h6>Total Revenue</h6>
        <h3>Ksh <?= number_format($totalSales) ?></h3>
    </div>
</div>

<div class="col-md-4">
    <div class="report-card">
        <h6>Today's Sales</h6>
        <h3>Ksh <?= number_format($todaySales) ?></h3>
    </div>
</div>

<div class="col-md-4">
    <div class="report-card">
        <h6>Total Orders</h6>
        <h3><?= $totalOrders ?></h3>
    </div>
</div>

</div>

<!-- CHART -->
<div class="card p-4 mt-4">
    <h5>📈 Sales Trend</h5>
    <canvas id="salesChart"></canvas>
</div>

<!-- TOP PRODUCTS -->
<div class="card p-4 mt-4">
    <h5>🏆 Top Selling Products</h5>

    <?php foreach($topProducts as $tp): ?>
        <div class="top-item">
            <span><?= $tp['product_name'] ?></span>
            <strong><?= $tp['qty'] ?> sold</strong>
        </div>
    <?php endforeach; ?>
</div>

<!-- SALES TABLE -->
<div class="card p-4 mt-4">
    <h5>📋 Recent Sales</h5>

    <table class="table table-striped mt-3">
        <tr>
            <th>Product</th>
            <th>Qty</th>
            <th>Total</th>
            <th>Date</th>
        </tr>

        <?php foreach($sales as $s): ?>
        <tr>
            <td><?= $s['product_name'] ?></td>
            <td><?= $s['quantity'] ?></td>
            <td>Ksh <?= $s['total'] ?></td>
            <td><?= $s['sale_date'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

</div>

<!-- CHART JS -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
const labels = <?= json_encode(array_column($chartData, 'day')) ?>;
const data = <?= json_encode(array_column($chartData, 'total')) ?>;

new Chart(document.getElementById('salesChart'), {
    type: 'line',
    data: {
        labels: labels,
        datasets: [{
            label: 'Sales',
            data: data,
            fill: true,
            tension: 0.4
        }]
    }
});
</script>

<!-- STYLING -->
<style>

/* CARDS */
.report-card {
    background: linear-gradient(135deg,#4b7bec,#3867d6);
    color:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
    transition:0.3s;
}

.report-card:hover {
    transform:translateY(-5px);
}

/* TOP PRODUCTS */
.top-item {
    display:flex;
    justify-content:space-between;
    padding:10px 0;
    border-bottom:1px solid #eee;
}

/* TABLE */
table {
    border-radius:10px;
    overflow:hidden;
}

</style>