<?php
include "config.php";
$current = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

<style>

/* SIDEBAR */
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 240px;
    height: 100vh;
    background: linear-gradient(180deg, #1e272e, #2f3640);
    padding-top: 20px;
    color: white;
    transition: 0.3s;
}

/* LOGO */
.sidebar h4 {
    text-align: center;
    margin-bottom: 30px;
    font-weight: bold;
}

/* LINKS */
.sidebar a {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #dcdde1;
    padding: 12px 20px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 15px;
}

/* HOVER */
.sidebar a:hover {
    background: rgba(255,255,255,0.1);
    color: white;
    padding-left: 25px;
}

/* ACTIVE */
.sidebar a.active {
    background: #4b7bec;
    color: white;
    border-left: 4px solid #fff;
}

/* ICONS */
.sidebar i {
    width: 20px;
    text-align: center;
}

/* CONTENT SHIFT */
.content {
    margin-left: 240px;
    padding: 20px;
    background: #f5f6fa;
    min-height: 100vh;
}

/* TOP BAR */
.topbar {
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

/* LOGOUT */
.logout {
    background:#e84118;
    border:none;
    padding:8px 15px;
    color:white;
    border-radius:8px;
}

</style>
</head>

<body>

<div class="sidebar">
    <h4>🛒 Doug Store</h4>

    <a href="index.php" class="<?= $current=='index.php'?'active':'' ?>">
        <i class="fas fa-chart-line"></i> Dashboard
    </a>

    <a href="sales.php" class="<?= $current=='sales.php'?'active':'' ?>">
        <i class="fas fa-cash-register"></i> Sales
    </a>

    <a href="products.php" class="<?= $current=='products.php'?'active':'' ?>">
        <i class="fas fa-box"></i> Products
    </a>

    <a href="reports.php" class="<?= $current=='reports.php'?'active':'' ?>">
        <i class="fas fa-chart-pie"></i> Reports
    </a>

    <a href="logout.php">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
</div>

<div class="content">

<div class="topbar">
    <h5>Welcome, Admin</h5>
    <button class="logout" onclick="window.location='logout.php'">Logout</button>
</div>