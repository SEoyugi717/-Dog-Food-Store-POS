<?php
// Start session safely if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "sidebar.php";

// Stats
$total_sales = $conn->query("SELECT COUNT(*) FROM sales WHERE DATE(sale_date)=CURDATE()")->fetchColumn();
$total_revenue = $conn->query("SELECT SUM(total) FROM sales WHERE DATE(sale_date)=CURDATE()")->fetchColumn();
$total_products = $conn->query("SELECT COUNT(*) FROM products")->fetchColumn();
$low_stock = $conn->query("SELECT COUNT(*) FROM products WHERE quantity <= 5")->fetchColumn();

// Recent sales
$recent_sales = $conn->query("SELECT * FROM sales ORDER BY sale_date DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Chart data (7 days)
$labels = [];
$data = [];
for($i=6;$i>=0;$i--){
    $date = date('D', strtotime("-$i days"));
    $full = date('Y-m-d', strtotime("-$i days"));
    $sum = $conn->query("SELECT SUM(total) FROM sales WHERE DATE(sale_date)='$full'")->fetchColumn();
    $labels[] = $date;
    $data[] = $sum ?: 0;
}
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="container-fluid">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 style="font-weight:700;">Dashboard Overview</h2>
    <span style="color:gray;">
        Welcome back, <?= isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin'; ?>
    </span>
</div>
<!-- HEADER -->

<!-- KPI CARDS -->
<div class="row g-4 mb-4">

    <div class="col-md-3">
        <div class="card kpi-card bg-primary text-white">
            <div>
                <h6>Sales Today</h6>
                <h2 class="counter"><?= $total_sales ?></h2>
            </div>
            <span>📦</span>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card kpi-card bg-success text-white">
            <div>
                <h6>Revenue</h6>
                <h2>Ksh <?= number_format($total_revenue ?: 0,2) ?></h2>
            </div>
            <span>💰</span>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card kpi-card bg-dark text-white">
            <div>
                <h6>Total Products</h6>
                <h2><?= $total_products ?></h2>
            </div>
            <span>📊</span>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card kpi-card bg-danger text-white">
            <div>
                <h6>Low Stock</h6>
                <h2><?= $low_stock ?></h2>
            </div>
            <span>⚠️</span>
        </div>
    </div>

</div>

<!-- CHARTS -->
<div class="row g-4 mb-4">

    <div class="col-lg-8">
        <div class="card p-4">
            <h5 class="mb-3">Sales (Last 7 Days)</h5>
            <canvas id="salesChart"></canvas>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card p-4">
            <h5 class="mb-3">Stock Status</h5>
            <canvas id="stockChart"></canvas>
        </div>
    </div>

</div>

<!-- RECENT SALES -->
<div class="card p-4">
    <h5 class="mb-3">Recent Sales</h5>
    <table class="table table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Product</th>
                <th>Qty</th>
                <th>Total</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($recent_sales as $s): ?>
            <tr>
                <td><?= $s['id'] ?></td>
                <td><?= $s['product_name'] ?></td>
                <td><?= $s['quantity'] ?></td>
                <td>Ksh <?= $s['total'] ?></td>
                <td><?= date("d M Y H:i", strtotime($s['sale_date'])) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</div>

<!-- CHART JS -->
<script>
const salesChart = new Chart(document.getElementById('salesChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
            label: 'Revenue',
            data: <?= json_encode($data) ?>,
            borderWidth: 3,
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        plugins: { legend: { display: false }},
        responsive: true
    }
});

const stockChart = new Chart(document.getElementById('stockChart'), {
    type: 'doughnut',
    data: {
        labels: ['Low Stock', 'Available'],
        datasets: [{
            data: [<?= $low_stock ?>, <?= $total_products - $low_stock ?>]
        }]
    },
    options: {
        plugins: { legend: { position: 'bottom' }}
    }
});
</script>

<!-- EXTRA CSS -->
<style>

/* KPI Cards */
.kpi-card {
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:20px;
    border-radius:12px;
    transition:0.3s;
    cursor:pointer;
}

.kpi-card span {
    font-size:30px;
    opacity:0.7;
}

.kpi-card:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
}

/* Table */
.table {
    border-radius:10px;
    overflow:hidden;
}

.table thead {
    background:#2f3640;
    color:white;
}

/* Card general */
.card {
    border:none;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
}

/* Smooth fade-in */
.container-fluid {
    animation: fadeIn 0.4s ease-in;
}

@keyframes fadeIn {
    from {opacity:0; transform:translateY(10px);}
    to {opacity:1; transform:translateY(0);}
}

</style>